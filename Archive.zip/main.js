import Phaser from "phaser"

import {
	easystar,
	generateOpenMap,
	endPlayerTurn,
	endAiTurn,
	updatePathIndicator,
	commitMove,
} from "./src/utils/common.js"
import Enemy from "./src/utils/enemy.js"

import { constants } from "./src/utils/constants.js"

export let mapData = []

let enemies = []

const config = {
	type: Phaser.AUTO,
	width: 800,
	height: 600,
	parent: "game-container",
	scene: {
		preload: preload,
		update: update,
		create: create,
	},
}

const game = new Phaser.Game(config)

function preload() {
	// Load assets (images, sprites, etc.)
}

function create() {
	// Generate a random maze

	mapData = generateOpenMap(constants.mapWidth, constants.mapHeight, 0.1) // 10% chance of an obstacle

	// Configure EasyStar.js
	easystar.setGrid(mapData)
	easystar.setAcceptableTiles([0]) // Assuming '0' is a walkable tile

	// Create the map

	for (let y = 0; y < mapData.length; y++) {
		for (let x = 0; x < mapData[y].length; x++) {
			const tileType = mapData[y][x]
			const color = tileType === 1 ? 0x333333 : 0xaaaaaa // Dark for blocked, light for walkable
			this.add
				.rectangle(
					x * constants.tileSize,
					y * constants.tileSize,
					constants.tileSize,
					constants.tileSize,
					color
				)
				.setOrigin(0, 0)
		}
	}

	// Initialize the path indicator
	this.pathIndicator = this.add.graphics()

	// Configure EasyStar.js for diagonal movement
	easystar.enableDiagonals()
	// easystar.disableCornerCutting() // Optional, to prevent moving diagonally through walls

	// Placeholder for player character
	this.player = this.add.rectangle(20, 20, 30, 30, 0x00ff00)
	// Placeholder for an enemy

	for (let i = 0; i < 1; i++) {
		// Create a Phaser rectangle sprite for each enemy
		let enemySprite = this.add.rectangle(60, 20, 30, 30, 0xff0000)
		let enemy = new Enemy(enemySprite, 0, 5)
		enemies.push(enemy)
	}

	this.input.on("pointermove", (pointer) => {
		updatePathIndicator.call(this, pointer, mapData)
	})

	this.input.on("pointerdown", (pointer) => {
		commitMove.call(this, pointer, mapData)
	})

	this.remainingDistanceText = this.add.text(
		600,
		10,
		"Moves Left: " + constants.remainingMoveDistance,
		{ fill: "#fff" }
	)

	// Create an "End Turn" button
	let endTurnButton = this.add
		.text(700, 550, "End Turn", { fill: "#0f0" })
		.setInteractive()
		.on("pointerdown", () => {
			if (constants.currentPlayerTurn) {
				endPlayerTurn(this)
			}
		})
}

function update() {
	const movementSpeed = 4 // Lower value for slower movement

	if (constants.currentPlayerTurn) {
		if (this.player.path && this.player.pathIndex < this.player.path.length) {
			const point = this.player.path[this.player.pathIndex]
			const targetX = point.x * constants.tileSize + constants.tileSize / 2
			const targetY = point.y * constants.tileSize + constants.tileSize / 2

			if (
				Math.abs(this.player.x - targetX) > movementSpeed ||
				Math.abs(this.player.y - targetY) > movementSpeed
			) {
				this.player.x += movementSpeed * Math.sign(targetX - this.player.x)
				this.player.y += movementSpeed * Math.sign(targetY - this.player.y)
			} else {
				this.player.x = targetX
				this.player.y = targetY
				this.player.pathIndex++
			}
		}
	} else {
		console.log("AI turn")
		// Update each enemy
		enemies.forEach((enemy) => enemy.performTurn())

		endAiTurn()
	}
}
