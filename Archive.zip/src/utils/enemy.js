import { constants } from "./constants.js"
import { mapData } from "../../main.js"
export default class Enemy {
	constructor(sprite, visionCone, maxMoveDistance) {
		this.sprite = sprite
		this.visionCone = visionCone
		this.maxMoveDistance = maxMoveDistance
		this.state = "idle" // Possible states: 'idle', 'alerted'
		this.currentMoveDistance = 0 // Tracks the distance moved in the current turn
		this.moving = false // Is the enemy currently moving?
		this.targetPosition = null // Target position for the current move
	}

	performTurn() {
		if (this.state === "idle") {
			// Randomly choose between standing and walking
			// if (Math.random() < 0.5) {
			// 	this.stand()
			// } else {
			this.walk()
			// }
		}

		// Other states like 'alerted' can be added here
	}

	stand() {
		// The AI does nothing and ends its turn
	}

	walk() {
		const direction = this.getRandomDirection()
		this.targetPosition = {
			x: this.sprite.x + direction[0] * constants.tileSize,
			y: this.sprite.y + direction[1] * constants.tileSize,
		}
		if (this.isValidMove(this.targetPosition.x, this.targetPosition.y)) {
			this.moving = true
		}
	}

	getRandomDirection() {
		// Returns a random direction (up, down, left, right)
		const directions = [
			[0, -1],
			[1, 0],
			[0, 1],
			[-1, 0],
		]
		return directions[Math.floor(Math.random() * directions.length)]
	}

	isValidMove(x, y) {
		const gridX = Math.floor(x / constants.tileSize)
		const gridY = Math.floor(y / constants.tileSize)

		// Check if the move is within the game boundaries
		if (
			gridX < 0 ||
			gridX >= constants.mapWidth ||
			gridY < 0 ||
			gridY >= constants.mapHeight
		) {
			return false
		}

		// Check if the tile is walkable (not an obstacle)
		if (mapData[gridY][gridX] === 1) {
			// Assuming '1' is an obstacle
			return false
		}

		return true // The move is valid
	}

	update(playerPosition) {
		if (this.moving && this.currentMoveDistance < this.maxMoveDistance) {
			// Move towards the target position
			this.sprite.x = this.targetPosition.x
			this.sprite.y = this.targetPosition.y

			this.currentMoveDistance++
			if (this.currentMoveDistance >= this.maxMoveDistance) {
				this.moving = false // Stop moving after reaching max distance
				this.currentMoveDistance = 0 // Reset the distance for the next turn
			} else {
				// Prepare for the next move
				const direction = this.getRandomDirection()
				this.targetPosition = {
					x: this.sprite.x + direction[0] * constants.tileSize,
					y: this.sprite.y + direction[1] * constants.tileSize,
				}
				if (!this.isValidMove(this.targetPosition.x, this.targetPosition.y)) {
					this.moving = false
					this.currentMoveDistance = 0
				}
			}
		}
	}

	idleBehavior() {
		// Define idle behavior: patrolling, waiting, etc.
	}

	alertedBehavior(playerPosition) {
		// Define behavior when alerted: chasing the player, etc.
	}

	checkPlayerVisibility(playerPosition) {
		// Perform a perception check to see if the player is visible
		// If visible, change state to 'alerted'
		if (this.isPlayerVisible(playerPosition)) {
			this.state = "alerted"
		}
	}

	isPlayerVisible(playerPosition) {
		// Implement vision cone logic and perception check here
		// Return true if player is spotted
	}
}
